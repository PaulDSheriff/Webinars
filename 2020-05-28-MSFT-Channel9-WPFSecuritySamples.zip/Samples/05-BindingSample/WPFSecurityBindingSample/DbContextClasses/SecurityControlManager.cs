﻿using System.Collections.Generic;
using System.Linq;
using WPF.Security;

namespace WPFSecurityBindingSample
{
  public class SecurityControlManager
  {
    #region GetSecurityControls Method
    public List<SecurityControl> GetSecurityControls(string containerName)
    {
      List<SecurityControl> ret = new List<SecurityControl>();

      using (WpfSecurityDbContext db = new WpfSecurityDbContext())
      {
        ret.AddRange(db.ControlsToSecure.Where(s => s.ContainerName == containerName).ToList());
      }

      return ret;
    }
    #endregion
  }
}