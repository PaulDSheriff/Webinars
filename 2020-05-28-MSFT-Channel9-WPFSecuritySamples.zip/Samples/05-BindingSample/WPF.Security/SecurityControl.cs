﻿using System.ComponentModel.DataAnnotations.Schema;

namespace WPF.Security
{
  /// <summary>
  /// This class contains information about a XAML control
  /// </summary>
  [Table("SecurityControl")]
  public class SecurityControl
  {
    #region Properties
    /// <summary>
    /// Get/Set the Security Control Id (Primary Key)
    /// </summary>
    public int SecurityControlId { get; set; }
   
    /// <summary>
    /// Get/Set the WPF container name for the elements
    /// </summary>
    public string ContainerName { get; set; }

    /// <summary>
    /// Get/Set the Element identifier. This can be the control name, or the value in the Tag property
    /// </summary>
    public string ElementIdentifier { get; set; }

    /// <summary>
    /// Get/Set the Mode
    /// Mode=Disabled,ReadOnly,Collapsed,Hidden
    /// </summary>
    public string Mode { get; set; }

    /// <summary>
    /// Get/Set the Roles as a comma-delimited string
    /// </summary>
    private string _RolesAsString = string.Empty;
    public string RolesAsString
    {
      get { return _RolesAsString; }
      set {
        _RolesAsString = value;
        Roles = _RolesAsString.Split(',');
      }
    }

    /// <summary>
    /// Get/Set the Roles
    /// </summary>
    public string[] Roles { get; set; }
    #endregion

    #region ToString() Override
    /// <summary>
    /// Returns ElementIdentifier-Mode-RolesAsString
    /// </summary>
    /// <returns>A string</returns>
    public override string ToString()
    {      
      return ElementIdentifier + "-" + Mode + "-" + RolesAsString;
    }
    #endregion
  }
}
