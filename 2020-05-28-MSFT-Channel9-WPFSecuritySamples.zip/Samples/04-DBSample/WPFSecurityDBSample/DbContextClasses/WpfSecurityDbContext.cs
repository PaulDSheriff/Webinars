﻿using System.Data.Entity;
using WPF.Security;

namespace WPFSecurityDBSample
{
  public class WPFSecurityDbContext : DbContext
  {
    public WPFSecurityDbContext() : base("name=Sandbox")
    {
    }

    public virtual DbSet<SecurityControl> ControlsToSecure { get; set; }

    protected override void OnModelCreating(DbModelBuilder modelBuilder)
    {
      // Don't let EF create migrations or check database for model consistency
      Database.SetInitializer<WPFSecurityDbContext>(null);

      base.OnModelCreating(modelBuilder);
    }
  }
}
