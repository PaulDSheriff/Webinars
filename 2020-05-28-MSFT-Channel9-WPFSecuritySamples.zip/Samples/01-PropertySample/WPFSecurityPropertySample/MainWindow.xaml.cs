﻿using System.Security.Principal;
using System.Threading;
using System.Windows;
using WPFSecurityPropertySample.ViewModels;

namespace WPFSecurityPropertySample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();

      _viewModel = (EmployeeViewModel)this.Resources["viewModel"];
    }

    private readonly EmployeeViewModel _viewModel;

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      // Set your Security Principal
      SetSecurityPrincipal();

      // Secure controls on this WPF window
      _viewModel.SecureControls();
    }

    private void SetSecurityPrincipal()
    {
      // Set Principal to a WindowsPrincipal
      Thread.GetDomain().SetPrincipalPolicy(PrincipalPolicy.WindowsPrincipal);

      // NOTE: You could create a GenericPrincipal here with your own credentials and roles
    }
  }
}
