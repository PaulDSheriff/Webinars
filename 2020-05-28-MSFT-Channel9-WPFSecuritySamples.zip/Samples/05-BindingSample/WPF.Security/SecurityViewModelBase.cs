﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace WPF.Security
{
  public class SecurityViewModelBase
  {
    #region Constructor
    public SecurityViewModelBase()
    {
      ControlsToSecure = new List<SecurityControl>();
      ControlsInContainer = new List<XAMLControlInfo>();
    }
    #endregion

    #region Properties
    public List<SecurityControl> ControlsToSecure { get; set; }
    public List<XAMLControlInfo> ControlsInContainer { get; set; }
    public IPrincipal CurrentPrincipal { get; set; }
    #endregion

    #region SecureControls Method
    /// <summary>
    /// Secure controls within the XAML element passed in
    /// </summary>
    /// <param name="element">A WPF Control such as a Window, User Control, Grid or StackPanel</param>
    /// <param name="containerName">The name of a Window or User Control you wish to secure.</param>
    public virtual void SecureControls(object element, string containerName)
    {
      XAMLControlInfo ctl = null;

      // Get Current Principal
      CurrentPrincipal = Thread.CurrentPrincipal;

      // Get Controls to Secure from Data Store
      LoadControlsToSecure(containerName);

      // Build List of Controls in XAML Element to be Secured
      LoadControlsInXAMLContainer(element);

      // Loop through controls
      foreach (SecurityControl secCtl in ControlsToSecure) {
        secCtl.ElementIdentifier = secCtl.ElementIdentifier.ToLower();
        // Search for Name property
        ctl = ControlsInContainer.Find(c => c.ControlName.ToLower() == secCtl.ElementIdentifier);
        // *** BEGIN: NEW CODE HERE ***
        if (ctl == null) {
          // Search for BindingPath
          ctl = ControlsInContainer.Find(c => c.BindingPath.ToLower() == secCtl.ElementIdentifier);
        }
        // *** END: NEW CODE HERE ***
        if (ctl == null) {
          // Search for Tag property
          ctl = ControlsInContainer.Find(c => c.Tag.ToLower() == secCtl.ElementIdentifier);
        }
        if (ctl != null && !string.IsNullOrWhiteSpace(secCtl.Mode)) {
          // Loop through roles and see if user is NOT in one of the roles
          // If they are not, then change the state of the control
          foreach (string role in secCtl.Roles) {
            if (CurrentPrincipal.IsInRole(role)) {
              // They are in a role, so break out of loop
              break;
            }
            else {
              // They are NOT in a role, so change the control state
              ChangeState(ctl, secCtl.Mode);
              // Break out of loop because we have already modified the control state
              break;
            }
          }
        }
      }
    }
    #endregion

    #region ChangeState Method
    /// <summary>
    /// Sets a control's state based on the mode passed in.
    /// </summary>
    /// <param name="control">A Control object</param>
    /// <param name="mode">The mode to set</param>
    protected virtual void ChangeState(XAMLControlInfo control, string mode)
    {
      Control ctl = (Control)control.TheControl;

      switch (mode.ToLower()) {
        case "disabled":
          ctl.Visibility = Visibility.Visible;
          ctl.IsEnabled = false;
          break;
        case "readonly":
        case "read only":
        case "read-only":
          ctl.Visibility = Visibility.Visible;
          ctl.IsEnabled = true;
          if (control.HasIsReadOnlyProperty) {
            // Use reflection to turn on IsReadOnly property
            ctl.GetType().GetProperty("IsReadOnly").SetValue(control.TheControl, true, null);
          }
          else {
            ctl.IsEnabled = false;
          }
          break;
        case "collapsed":
        case "collapse":
          ctl.Visibility = Visibility.Collapsed;
          break;
        case "hidden":
        case "invisible":
          ctl.Visibility = Visibility.Hidden;
          break;
      }
    }
    #endregion

    #region LoadControlsToSecure Method
    /// <summary>
    /// Override this method to gather the list of controls to secure from a data store.
    /// The 'containerName' parameter allows you to specify the name of a XAML container within which is a list of controls to secure.
    /// </summary>
    /// <param name="containerName">The name of the XAML container you wish to secure.</param>
    protected virtual void LoadControlsToSecure(string containerName)
    {
    }
    #endregion

    #region LoadControlsInXAMLContainer Method
    /// <summary>
    /// Create a collection of controls from the WPF Window/User Control, etc. that is passed in.
    /// For example, you might pass in a Grid or StackPanel, and this method will 
    /// fill in the 'ControlsInContainer' property.
    /// </summary>
    /// <param name="element">A WPF Container control such as a Window, User Control, Grid or StackPanel</param>
    protected virtual void LoadControlsInXAMLContainer(object element)
    {
      XAMLControlInfo ctl;
      FrameworkElement fe;

      if (element is DependencyObject dep) {
        ctl = new XAMLControlInfo
        {
          TheControl = element,
          ControlType = element.GetType().Name
        };

        // Cast to 'FrameworkElement' so we can get the Name and Tag properties
        fe = element as FrameworkElement;
        if (fe != null) {
          ctl.ControlName = fe.Name;
          if (fe.Tag != null) {
            ctl.Tag = fe.Tag.ToString();
          }
        }

        // *** BEGIN: NEW CODE HERE ***
        // See if there are any data bindings
        ctl.BindingPath = GetBindingName(element as Control);
        // *** END: NEW CODE HERE ***

        if (ctl.ConsiderForSecurity()) {
          // Is there a ReadOnly property?
          ctl.HasIsReadOnlyProperty = element.GetType().GetProperty("IsReadOnly") == null ? false : true;

          // Make sure there is not a null in ControlName or Tag
          ctl.ControlName = ctl.ControlName ?? string.Empty;
          ctl.Tag = ctl.Tag ?? string.Empty;

          // Add control to be considered for security
          ControlsInContainer.Add(ctl);
        }

        // Look for Child objects
        foreach (object child in LogicalTreeHelper.GetChildren(dep)) {
          // Make recursive call
          LoadControlsInXAMLContainer(child);
        }
      }
    }
    #endregion

    #region GetBindingName Method
    /// <summary>
    /// Gets a Binding Path from a control. 
    /// For example, Text={Binding Path=FirstName}, this method returns 'FirstName'
    /// </summary>
    /// <param name="ctl">The control to check for a binding expression</param>
    /// <returns>A binding path name</returns>
    protected virtual string GetBindingName(Control ctl)
    {
      string ret = string.Empty;
      BindingExpression exp;
      DependencyProperty prop;

      if (ctl != null) {
        // Get the unique Dependency Property for each control
        // that can be used to get a {Binding Path=xxx} expression
        switch (ctl.GetType().Name.ToLower()) {
          case "textbox":
            prop = TextBox.TextProperty;
            break;
          case "label":
            prop = Label.ContentProperty;
            break;
          case "menuitem":
            prop = MenuItem.HeaderProperty;
            break;
          case "textblock":
            prop = TextBlock.TextProperty;
            break;
          case "combobox":
            prop = ComboBox.SelectedValueProperty;
            break;
          case "listbox":
            prop = ListBox.SelectedValueProperty;
            break;
          case "checkbox":
            prop = CheckBox.IsCheckedProperty;
            break;
          case "datepicker":
            prop = DatePicker.SelectedDateProperty;
            break;
          case "button":
            prop = Button.ContentProperty;
            break;
          case "datagrid":
            prop = DataGrid.DataContextProperty;
            break;
          case "grid":
            prop = Grid.DataContextProperty;
            break;
          case "radiobutton":
            prop = RadioButton.IsCheckedProperty;
            break;
          case "calendar":
            prop = Calendar.SelectedDateProperty;
            break;
          case "slider":
            prop = Slider.ValueProperty;
            break;
          default:
            // Add your own custom/third-party controls
            prop = GetBindingNameCustom(ctl);
            break;
        }

        if (prop != null) {
          // Get Binding Expression
          exp = ctl.GetBindingExpression(prop);

          // If we have a valid binding, attempt to get the binding path
          if (exp != null && exp.ParentBinding != null && exp.ParentBinding.Path != null) {
            if (!string.IsNullOrEmpty(exp.ParentBinding.Path.Path)) {
              ret = exp.ParentBinding.Path.Path;
            }
          }
        }
      }

      if (!string.IsNullOrEmpty(ret)) {
        if (ret.Contains(".")) {
          ret = ret.Substring(ret.LastIndexOf(".") + 1);
        }
      }

      return ret;
    }
    #endregion

    #region Virtual GetBindingNameCustom Method
    /// <summary>
    /// This method is virtual so you can override this method and add your own switch statement for any custom/third-party controls you wish to get the BindingExpression from
    /// </summary>
    /// <returns>A Binding Expression</returns>
    protected virtual DependencyProperty GetBindingNameCustom(Control control)
    {
      DependencyProperty prop = null;

      // Add your own custom control binding expressions here
      switch (control.GetType().Name.ToLower()) {
        case "my_custom_control":
          // prop = ControlType.BindingProperty;
          break;
      }

      return prop;
    }
    #endregion
  }
}
