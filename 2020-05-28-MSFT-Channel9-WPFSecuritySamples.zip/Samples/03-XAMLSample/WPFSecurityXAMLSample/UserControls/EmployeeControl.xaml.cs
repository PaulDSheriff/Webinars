﻿using System.Windows.Controls;

namespace WPFSecurityXAMLSample
{
  public partial class EmployeeControl : UserControl
  {
    public EmployeeControl()
    {
      InitializeComponent();
    }
  }
}
