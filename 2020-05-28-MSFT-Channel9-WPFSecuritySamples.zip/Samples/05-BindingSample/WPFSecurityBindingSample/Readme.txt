﻿WPF Security Sample
--------------------------------
This sample shows how to secure controls on a WPF element.
Controls may be secured by disabling, making them readonly, hidden, or collapsed
To identify the controls to be secured, create a collection of SecurityControl objects
	In each SecurityControl object, fill in the following properties
	- ElementIdentifier: Name of the control | The binding Path | Value in the Tag property
	- Mode: disabled | readonly | hidden | collapsed
	- RolesAsString: Comma-delimited list of roles user must be in to show control normally

SQL Script
----------------
There is a SecurityControl.sql file in the \SqlScript folder which builds the SecurityControl table which holds the data for the controls to secure

You will have to change the connection string in App.config to run this sample.


Changes from previous 'DB' sample
-----------------------------------------------------
Added BindingPath property to XAMLControlInfo class
Modified ConsiderForSecurity() method in XAMLControlInfo class to include BindingPath
Modified ToString() method in XAMLControlInfo class to include BindingPath

** SecurityViewModelBase Changes **
Added GetBindingName() method
Added GetBindingNameCustom() method
Added a search for BindingPath property in SecureControls() method
Call GetBindingName() method from LoadControlsInXAMLContainer()

** EmployeeControl.xaml Changes **
Removed 'Name' property from all TextBox controls
	This will allow the Binding.Path property to be used