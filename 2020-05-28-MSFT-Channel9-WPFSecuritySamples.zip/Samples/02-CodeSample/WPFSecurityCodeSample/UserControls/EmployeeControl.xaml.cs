﻿using System.Windows.Controls;

namespace WPFSecurityCodeSample
{
  public partial class EmployeeControl : UserControl
  {
    public EmployeeControl()
    {
      InitializeComponent();
    }
  }
}
