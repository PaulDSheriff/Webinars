namespace BootstrapLogin
{
  public class LoginViewModel
  {
    public LoginViewModel() {
      Entity = new LoginData();
      IsValid = true;
    }

    public LoginData Entity { get; set; }
    public bool IsValid { get; set; }
  }
}