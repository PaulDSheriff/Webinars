﻿using System.Windows.Controls;

namespace WPFSecurityDBSample
{
  public partial class EmployeeControl : UserControl
  {
    public EmployeeControl()
    {
      InitializeComponent();
    }
  }
}
