﻿using System.ComponentModel.DataAnnotations;

namespace BootstrapLogin
{
  public class LoginData
  {
    [Required(ErrorMessage = "Email is required.")]
    public string Email { get; set; }

    [Required(ErrorMessage = "Password is required.")]
    public string Password { get; set; }

    public bool IsRememberMeChecked { get; set; }
  }
}
