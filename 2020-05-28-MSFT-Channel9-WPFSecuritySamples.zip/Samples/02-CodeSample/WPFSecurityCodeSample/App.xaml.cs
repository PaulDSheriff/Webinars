﻿using System.Windows;

namespace WPFSecurityCodeSample
{
  public partial class App : Application
  {   
  }
}
