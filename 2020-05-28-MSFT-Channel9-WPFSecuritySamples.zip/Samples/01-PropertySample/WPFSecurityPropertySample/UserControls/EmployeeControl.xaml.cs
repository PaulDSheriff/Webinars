﻿using System.Windows.Controls;

namespace WPFSecurityPropertySample
{
  public partial class EmployeeControl : UserControl
  {
    public EmployeeControl()
    {
      InitializeComponent();
    }
  }
}
