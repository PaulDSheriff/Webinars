﻿using WPF.Security;

namespace WPFSecurityDBSample.ViewModels
{
  public class EmployeeViewModel : SecurityViewModelBase
  {
    public EmployeeViewModel() : base()
    {
      EmployeeID = 1;
      FirstName = "Bruce";
      LastName = "Jones";
      Salary = 75000;
      SSN = "555-55-5555";
    }

    public int EmployeeID { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public decimal Salary { get; set; }
    public string SSN { get; set; }

    #region LoadControlsToSecure Method
    protected override void LoadControlsToSecure(string containerName)
    {
      SecurityControlManager mgr = new SecurityControlManager();

      ControlsToSecure = mgr.GetSecurityControls(containerName);
    }
    #endregion
  }
}
