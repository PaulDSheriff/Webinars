﻿using System.Web.Mvc;

namespace BootstrapLogin.Controllers
{
  public class LoginController : Controller
  {
    public ActionResult Login1() {
      LoginViewModel vm = new LoginViewModel();

      return View(vm);
    }

    [HttpPost]
    public ActionResult Login1(LoginViewModel vm) {
      // Perform validation
      vm.IsValid = ModelState.IsValid;

      if (vm.IsValid) {
        return RedirectToAction("Index", "Home");
      }
      else {
        return View(vm);
      }
    }

    public ActionResult Login2() {
      LoginViewModel vm = new LoginViewModel();

      return View(vm);
    }

    [HttpPost]
    public ActionResult Login2(LoginViewModel vm) {
      // Perform validation
      vm.IsValid = ModelState.IsValid;

      if (vm.IsValid) {
        return RedirectToAction("Index", "Home");
      }
      else {
        return View(vm);
      }
    }
  }
}